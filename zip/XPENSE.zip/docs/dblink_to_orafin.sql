select * from yg_store_building_hdr@dwhtoorafin;

select * from yg_store_building_dtl@dwhtoorafin;

select distinct area_name from yg_store_building_dtl@dwhtoorafin;