<?php
    $user = "xpense";
    $pass = "xpenseteam";
    $dbname = "xpense";
    $host = "localhost";
    $webService = "http://venditore.yogya.com/ws";
    $filePath = "/Users/user/Data/Appl/XPENSE/docs";
?>