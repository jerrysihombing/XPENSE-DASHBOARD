
$(document).ready(function() {
	
	FormValidation.init();
	
	$(".btn-back").click(function() {
		location.href=baseUrl+"admin/contact";
	});
	
});
