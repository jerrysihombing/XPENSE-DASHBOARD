
$(document).ready(function() {
	
	FormValidation.init();
	
});
